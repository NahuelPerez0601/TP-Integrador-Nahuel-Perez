history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname TPServer
hostname man
man hostname
hostname set-hostname TPServer
hostnamectl
hostname set-hostname TPServer
hostnamectl set-hostname TPServer
hostnamectl
ip a
lsb release -a
cat /etc/debian_version 
apt update
nano /etc/network/interfaces
vi /etc/network/interfaces
ping 8.8.8.8
ip a
vi /etc/network/interfaces
systemctl restart networking
ip a
vi /etc/network/interfaces
systemctl restart networking
ip a
ping 8.8.8.8
vi /etc/network/interfaces
vi /etc/network/interfaces
systemctl restart networking
ip a
ping 8.8.8.8
vi /etc/network/interfaces
systemctl restart networkinkg
systemctl restart network
systemctl restart networkinkg
systemctl restart networking
ip a
ifup ens33
ping 8.8.8.8
apt update
apt upgrade
apt autoremove
sudo cp /etc/apt/source.list /etc/apt/sources.list.bak
ls
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt upgrade
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt upgrade
apt update
vi /etc/apt/sources.list
apt upgrade
reboot
ls /root/
shutdown now
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
sudo apt update
sudo apt upgrade -y
sudo apt install mariadb-server -y
systemctl status mariadb.s
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA/db.sql 
mariadb -e "show databases;"
vi /etc/network/interfaces
systemctl restart networking
ip a
ip a
vi /etc/ssh/sshd_config
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_p /root/.ssh/authorized_keys
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
chmod 600 /root/.ssh/authorized_keys 
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
ip a
shutdown -h now
fdisk -l
